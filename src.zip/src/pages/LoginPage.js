import React from "react";
import LoginButton from "../components/LoginButton";
import { useAuth0 } from "@auth0/auth0-react";
import { Navigate } from "react-router-dom";

const LoginPage = () => {
  const { isAuthenticated } = useAuth0();

  if (isAuthenticated) {
    return <Navigate to="/home" />;
  }

  return (
    <div>
      <div >
        <h1 >Welcome to <span >Kairos</span></h1>
        <p >Surprising Flavors, Anytime Anywhere!</p>
        <LoginButton />
      </div>
    </div>
  );
};

export default LoginPage;
